# Contrata Legal · Sigue el hilo

El anuncio conserva la interfaz Cristal de Flutter. Las tomas en pantalla usan capturas de ejecución de la app y la apertura gráfica usa la misma paleta: azul noche, azul de acción y amarillo cálido. Los nombres de roles aparecen en tipografía Inter animada. El logotipo de la plataforma firma el cierre.

## Montaje editable

`index.html` contiene la composición de HyperFrames a 1920 × 1080. Las tomas, acercamientos y clics están en la línea de tiempo de GSAP. `guion.md` describe qué acción acompaña cada frase. `subtitulos.srt` es la pista de subtítulos y `transcript.json` contiene sus tiempos en segundos.

Las capturas de consulta muestran datos públicos de SECOP II. Los flujos de Gestión Contractual y Supervisión usan un expediente y usuarios de demostración.

Para volver a exportar, abrir esta carpeta y ejecutar `npx hyperframes@0.9.91 render --output sigue-el-hilo.mp4 --quality high --fps 30`.
