# El hilo dorado

Contrata Legal · Anuncio horizontal de 60 segundos. El negro de apertura pasa al azul noche de Cristal. El hilo luminoso y las palabras de énfasis usan #FFC83D. Las interfaces, resultados y tarjetas se capturaron en la aplicación. El expediente y el informe mensual son demostraciones.

La composición HyperFrames usa tres planos a 1920 × 1080. El primero aporta contexto, el segundo anima recortes reales en perspectiva y el tercero dibuja titulares, subtítulos y el hilo. Las coordenadas de recorte en montaje.js corresponden a imágenes de referencia de 960 × 587. El perfil de Value and Risk Rating corresponde al proveedor de la primera fila del Cesar. El contador muestra su valor acumulado en el perfil capturado.

Para editar la secuencia, abrir montaje.js. cues.js fija los tiempos de la locución de Salomé en español de Colombia. La mezcla estéreo incorpora música y efectos compuestos para los cortes. Para exportar desde esta carpeta, ejecutar `npx hyperframes@0.9.91 render --fps 30 --quality high -o el-hilo-dorado.mp4`.
