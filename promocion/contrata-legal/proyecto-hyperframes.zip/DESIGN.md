# Contrata Legal · Sigue el hilo

Anuncio de producto de 60 segundos. Una pista escrita en una barra real abre
la historia. La edición corta entre acciones de la interfaz de Contrata Legal y
alterna con acercamientos, pausas, gráficos tipográficos y efectos de sonido.
La firma con el logotipo es el último plano.

## Identidad

Inter de la aplicación. Azul noche #07101F, tinta #0A1424, azul #60A5FA y oro
#FFC53D. Las pantallas ocupan el encuadre completo. Las superposiciones
identifican el gesto o la función y se sitúan fuera del subtítulo.

## Fuentes de las imágenes

Pantallas e interacciones capturadas en Flutter. Los resultados de consulta
reproducen información pública de SECOP II. Las fichas de gestión y supervisión
usan un expediente de demostración, identificado en pantalla. El diálogo de
comparación y sus gráficas provienen de la aplicación.
