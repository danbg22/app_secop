// Composición HyperFrames. Unidades de diseño: 960 × 540. El render duplica la resolución.
const [fondo,tarjeta,fx]=['escena','plano','luz'].map(id=>document.getElementById(id).getContext('2d'));
const oro='#FFC83D',blanco='#F7FAFF',noche='#07101D',azul='#94BFFF';
const fotos={}, estados=['abiertos','adjudicados','cancelados'];
const archivos=['perfil','cesar-resultado','comparador','procesos-menu',...estados.map(s=>'procesos-'+s),'expediente','juridico-enlace','juridico-cargar','juridico-documentos','juridico-recibido','supervision-revision',...Array.from({length:22},(_,i)=>'tipo-'+i),'marca'];
const precarga=archivos.map(n=>{const im=new Image();im.src='assets/'+n+(n==='marca'?'.png':'.jpg');document.querySelector('#recursos').append(im);fotos[n]=im;return im.decode()});
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x)), lerp=(a,b,p)=>a+(b-a)*p;
const ease=x=>1-(1-clamp(x))**3, smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
const reloj={s:0};let listo=false,t=0,ancla=[590,315];
function rect(c,x,y,w,h,color,r=0){c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill()}
function marco(c,x,y,w,h,color=oro){c.strokeStyle=color;c.lineWidth=2;c.beginPath();c.roundRect(x,y,w,h,8);c.stroke()}
function texto(c,msg,x,y,tam,color=blanco,weight=800,align='center'){
 c.font=weight+' '+tam+'px Inter';c.textAlign=align;c.textBaseline='middle';c.fillStyle=color;c.fillText(msg,x,y);
}
function rotulo(msg,y=94,tam=60){texto(fx,msg,480,y,tam)}
function titular(msg,a,b,y=258,size=74,color=blanco){
 if(t<a||t>=b)return;const p=ease((t-a)/.19),fin=smooth((b-t)/.12);
 fx.save();fx.globalAlpha=p*fin;fx.translate(480,y+20*(1-p));fx.scale(.89+.11*p,.89+.11*p);texto(fx,msg,0,0,size,color);fx.restore();
}
function rec(c,n,box,x,y,w,h){
 const im=fotos[n];const [sx,sy,sw,sh]=box;
 c.drawImage(im,sx*im.width/960,sy*im.height/587,sw*im.width/960,sh*im.height/587,x,y,w,h);
}
function contexto(n,osc=.40,zoom=1,dx=0,dy=0){
 fondo.save();fondo.translate(480+dx,270+dy);fondo.scale(zoom,zoom);rec(fondo,n,[0,0,960,540],-480,-270,960,540);fondo.restore();rect(fondo,0,0,960,540,'rgba(3,9,19,'+osc+')');
}
function flota(n,box,x,y,w,h,desde,tilt=9){
 const e=ease((t-desde)/.32);
 tarjeta.canvas.style.transform='perspective(2400px) rotateY('+((1-e)*tilt*1.4+tilt*.85+Math.sin(t*1.8)*1.4)+'deg) rotateX('+(-3+Math.sin(t)*1.2)+'deg)';
 tarjeta.save();tarjeta.globalAlpha=e;tarjeta.translate(x+w/2,y+h/2+19*(1-e));const z=.94+.06*e;tarjeta.scale(z,z);
 tarjeta.shadowColor='#000b';tarjeta.shadowBlur=19;rect(tarjeta,-w/2,-h/2,w,h,'#132139',10);tarjeta.shadowBlur=0;
 tarjeta.beginPath();tarjeta.roundRect(-w/2,-h/2,w,h,10);tarjeta.clip();rec(tarjeta,n,box,-w/2,-h/2,w,h);tarjeta.restore();
}
function puntero(x,y,at){
 const u=t-at;if(u<-.20||u>.45)return;
 fx.save();fx.translate(x+23*(1-ease((u+.20)/.2)),y+25*(1-ease((u+.20)/.2)));
 if(u>=0){fx.globalAlpha=1-clamp(u/.45);fx.strokeStyle=oro;fx.lineWidth=2;fx.beginPath();fx.arc(0,0,4+36*u/.45,0,Math.PI*2);fx.stroke()}
 fx.fillStyle=blanco;fx.beginPath();fx.moveTo(0,0);fx.lineTo(5,22);fx.lineTo(10,15);fx.lineTo(18,14);fx.closePath();fx.fill();fx.restore();
}
function marca(x,y,w,h,p){
 const im=fotos.marca,ratio=im.width/im.height;h=Math.min(h,w/ratio);w=h*ratio;
 fx.save();fx.translate(x-w/2,y-h/2);fx.strokeStyle=oro;fx.lineWidth=1.8;
 for(const ruta of contornos){const count=Math.round(ruta.length*clamp(p*1.35));fx.beginPath();for(let i=0;i<count;i++){const [xx,yy]=ruta[i];if(i===0)fx.moveTo(xx*w,yy*h);else fx.lineTo(xx*w,yy*h)}fx.stroke()}
 fx.globalAlpha=smooth((p-.2)/.6);fx.drawImage(im,0,0,w,h);fx.restore()
}
function guia(x,y){ancla=[x,y]}
function inicio(){
 if(t<3){
  fondo.fillStyle='#020305';fondo.fillRect(0,0,960,540);
  titular('¿Quién se queda',.14,3,214,70);titular('con los',.62,3,291,64);
  if(t>.87){rect(fx,0,256,960,95,'#020305');texto(fx,'con los',322,291,65);texto(fx,'contratos?',611,291,71,oro)}
  guia(452+238*ease((t-.82)/1.2),337);
 }else if(t<8){
  const u=t-3;
  if(u<1.65){for(let i=0;i<3;i++){if(u>i*.51){texto(fx,'Pestaña.',462+i*19,165+i*72,73,i===Math.min(2,Math.floor(u/.51))?oro:'#8193ab')}}}
  else if(u<2.67)titular('SECOP II.',4.6,5.7,260,108);
  else if(u<3.94){titular('Horas buscando.',5.64,6.95,217,70);titular('Y nada.',5.87,6.95,306,91,oro)}
  else if(u>4.49)titular('Se acabó.',7.48,8.02,268,93,oro);
  guia(610,355);
 }else{
  marca(480,218,320,155,ease((t-8)/1.18));const chips=['Persona','Equipo Jurídico','Supervisión','Entidades'];const xs=[179,310,511,674],ws=[115,184,146,125];
  chips.forEach((s,i)=>{let p=ease((t-9.33-i*.16)/.3);fx.save();fx.globalAlpha=p;rect(fx,xs[i],329+15*(1-p),ws[i],42,'#1b2c48',20);texto(fx,s,xs[i]+ws[i]/2,350+15*(1-p),17);fx.restore()});guia(750,379);
 }
}
const fila=[60,382,882,61],buscador=[0,0,960,587];
function contratos(){
 contexto('cesar-resultado',t<14.7?.88:.74,1.03);
 if(t<14.9){
  const k=Math.floor(clamp((t-12.61)/1.47)*21);
  titular('Escribe.',12,14.19,156,76);
  titular('Enter.',14.19,14.93,156,73,oro);
  flota('tipo-'+k,buscador,113,232,734,89,12.04,5);marco(fx,107,228,746,98,'#ffc83dba');
  guia(145+clamp(k/21)*321,309);puntero(830,270,14.47)
 }else{
  const p=ease((t-14.9)/.38);
  titular('Ya.',14.92,15.56,105,74,oro);titular('Contratos al instante.',15.55,19,105,58);
  for(let i=2;i>=0;i--){const e=ease((t-14.92-i*.085)/.35);if(e>0){tarjeta.save();tarjeta.globalAlpha=e*(1-i*.22);rec(tarjeta,'cesar-resultado',[62,405+i*37,879,35],66,285+i*30+(1-e)*34,828,37);tarjeta.restore()}}
  flota('cesar-resultado',fila,43,181,874,82,14.93,8);
  const k=t<16.82?0:t<18.05?1:2;
  const boxes=[[613,183,88,75],[444,183,163,75],[763,183,82,75]];
  const b=boxes[k];marco(fx,...b);guia(b[0]+b[2]*p,b[1]+b[3]+7);
 }
}
function proveedor(){
 contexto('perfil',.82,1.03);
 if(t<20.70){titular('¿Cuánto ha contratado?',19,20.74,126,60);flota('perfil',[64,57,876,107],71,216,818,104,19.01,-10);guia(650,332)}
 else{
  flota('perfil',[65,59,866,99],171,120,618,73,20.72,9);
  const p=ease((t-20.72)/1.25);const v=Math.round(11395341612*p);texto(fx,'$ '+String(v).replace(/\B(?=(\d{3})+(?!\d))/g,'.'),480,273,83,oro);
  texto(fx,'Valor total contratado',480,350,23,'#d1deed',500);guia(108+746*p,320);
 }
}
function comparar(){
 contexto('comparador',.77,1.02);
 titular('Compara entidades.',24,29,79,57);
 const p=ease((t-24)/.45);flota('comparador',[187,85,285,133],91-480*(1-p),135,370,146,24,-10);
 flota('comparador',[480,85,290,133],496+480*(1-p),135,370,146,24,10);
 const bx=213,by=293,bw=535,bh=157;
 rec(fx,'comparador',[189,231,586,265],bx,by,bw,bh);
 for(let k=0;k<3;k++){
  const age=ease((t-25.33-k*.22)/1.1);
  const yy=[by+21,by+73,by+125][k];
  rect(fx,bx+120+317*age,yy,317*(1-age),17,'#172538');
 }
 marco(fx,bx-4,by-4,bw+8,bh+8);guia(bx+bw-11,by+bh+8)
}
function procesos(){
 const tiempos=[29.19,30.49,31.79];let i=t<tiempos[1]?0:t<tiempos[2]?1:2;
 const n='procesos-'+estados[i],label=['Abiertos.','Adjudicados.','Cancelados.'][i],color=['#80EDB3',oro,'#FFA7A9'][i];
 contexto(t<29.19?'procesos-menu':n,.67,1.03);
 flota('procesos-menu',[111,251,165,251],66,112,156,235,29,-10);
 const cy=[170,230,260][i];puntero(143,cy,tiempos[i]);if(t>=tiempos[i]){marco(fx,71,cy-13,143,26,color);texto(fx,label,568,156,62,color);
 flota(n,[106,280,791,177],272,225,619,142,tiempos[i],8)}
 guia(863,380);
}
function legal(){
 const step=t<36.06?0:t<37.71?1:2;
 const screen=['expediente','juridico-enlace',t<39.12?'juridico-cargar':t<40.72?'juridico-documentos':'juridico-recibido'][step];
 contexto(screen,.69,1.045);
 for(let i=0;i<3;i++){const x=437+i*43;rect(fx,x-12,33,25,25,i===step?oro:'#253952',13);texto(fx,String(i+1),x,46,14,i===step?noche:blanco)}
 rotulo(['Crea el contrato.','Envía el link.','Documentos en tiempo real.'][step],106,step===2?47:59);
 if(step===0){flota(screen,[97,67,465,505],299,158,361,291,34,-9);guia(591,440)}
 else if(step===1){flota(screen,[308,183,345,222],269,157,430,268,36.06,10);const p=ease((t-36.83)/.83);fx.save();fx.translate(636+p*230,348-p*121);fx.rotate(-.67);fx.strokeStyle=oro;fx.lineWidth=4;for(let k=0;k<2;k++){fx.beginPath();fx.roundRect(-17+17*k,-7,23,14,7);fx.stroke()}fx.restore();guia(636+p*230,348-p*121);puntero(629,377,36.7)}
 else{const legal=t>=40.72;const box=legal?[97,250,461,121]:[172,316,615,100];flota(screen,box,89,214,778,legal?170:136,legal?40.72:37.71,-8);
 if(!legal)puntero(813,303,38.92);guia(legal?521:730,legal?383:352)}
}
function supervision(){
 contexto('supervision-revision',t<44.6?.35:.81,1.03);
 titular('Supervisión de contratos.',42,44.55,99,55);
 if(t<44.63){flota('supervision-revision',[33,56,888,74],87,266,786,84,42.05,9);guia(765,355)}
 else{
 rotulo('Verificación automática',77,51);
 const box=[573,270,348,211];const x=192,y=137,w=576,h=316;
 rec(tarjeta,'supervision-revision',box,x,y,w,h);marco(fx,x-3,y-3,w+6,h+6);
 const rows=[334,353,367,385,436,455], times=[44.86,45.31,45.75,46.2,46.66,47.10];let active=0;
 rows.forEach((row,i)=>{const yy=y+(row-box[1])*h/box[3];const p=ease((t-times[i])/.24);if(p>0)active=i;
 if(p<1)rect(fx,x+11,yy-10,553,20,'rgba(17,30,48,'+(.86*(1-p))+')');
 if(p>0&&p<1){fx.strokeStyle=(i===0||i===5)?'#85e9a4':'#ff8491';fx.lineWidth=3;fx.beginPath();fx.arc(x+37,yy,7+p*8,0,6.29);fx.stroke()}});
 guia(x+30,y+(rows[active]-box[1])*h/box[3]+13)
 }
}
function montaje(){
 const i=Math.min(4,Math.floor((t-49)/.6));const arr=['cesar-resultado','perfil','comparador','procesos-abiertos','supervision-revision'];
 contexto(arr[i],t<52?.24:.80,1.04+clamp((t-49-i*.6)/.6)*.06);
 if(t>=52){titular('Todo.',52,52.42,248,99,oro);titular('En una sola app.',52.4,53,252,79)}
 guia(780,362)
}
function cierre(){
 const p=ease((t-53)/.8);marca(480,157,244+4*Math.sin((t-53)*1.3),138,p);
 titular('Encuentra la pista.',53.47,60.3,266,55);titular('Sigue el hilo.',54.61,60.3,329,58,oro);
 if(t>=56.14){const u=ease((t-56.14)/.52),w=224*u*(1+.012*Math.sin(t*5));rect(fx,480-w/2,389,w,52*u,oro,14);if(u>.7)texto(fx,'Regístrate ya',480,415,27,noche);if(t>56.8)texto(fx,'Descarga la app',480,460,15,'#D0D9E7',500);guia(480+w/2-14,390)}
 else guia(477,232);
}
const limites=[0,3,8,12,19,24,29,34,42,49,49.6,50.2,50.8,51.4,53,56.14,60];
function hilo(){
 if(t<.77||(t>=6.97&&t<7.48))return;
 const jump=limites.find(s=>s>0&&s<60&&t>=s-.15&&t<s+.20);
 let [x,y]=ancla;let trail=120;
 if(jump!==undefined){let q=clamp((t-jump+.15)/.35);x=-100+1180*q;y=280+92*Math.sin(q*Math.PI*2+.4);trail=255;
  const g=fx.createLinearGradient(x-210,0,x,0);g.addColorStop(0,'#ffcb3700');g.addColorStop(1,'#ffdc7b44');rect(fx,x-210,0,210,540,g)}
 else {x+=Math.sin(t*2.1)*4;y+=Math.sin(t*2.9)*2;}
 if(t>=56.5){const u=(t-56.5)*2.1;x=480+108*Math.cos(u);y=415+26*Math.sin(u);trail=29}
 const birth=ease((t-.77)/.48);const g=fx.createLinearGradient(x-trail*birth-.01,0,x+1,0);g.addColorStop(0,'#ffc83d00');g.addColorStop(.55,'#ffc83d90');g.addColorStop(1,'#ffe69a');
 fx.strokeStyle=g;fx.lineWidth=2.4;fx.shadowColor=oro;fx.shadowBlur=8;fx.beginPath();fx.moveTo(x-trail*birth,y+Math.sin(t*4)*11);fx.bezierCurveTo(x-trail*.55*birth,y-12,x-32*birth,y+8,x,y);fx.stroke();fx.fillStyle='#fff0b9';fx.beginPath();fx.arc(x,y,2.6+.5*Math.sin(t*7),0,6.29);fx.fill();fx.shadowBlur=0;
}
function render(s){
 if(!listo)return;t=s;
 for(const c of [fondo,tarjeta,fx]){c.setTransform(2,0,0,2,0,0);c.clearRect(0,0,960,540)}
 tarjeta.canvas.style.transform='';
 const bg=fondo.createRadialGradient(475+24*Math.sin(t*.65),233,2,480,253,590);
 bg.addColorStop(0,'#193455');bg.addColorStop(.58,'#0d1b30');bg.addColorStop(1,'#050914');rect(fondo,0,0,960,540,bg);
 if(t<12)inicio();else if(t<19)contratos();else if(t<24)proveedor();else if(t<29)comparar();else if(t<34)procesos();else if(t<42)legal();else if(t<49)supervision();else if(t<53)montaje();else cierre();
 hilo();
 const c=cues.find(c=>t>=c.start&&t<c.end);
 if(c){fx.font='500 18px Inter';let w=fx.measureText(c.text).width+26;rect(fx,480-w/2,490,w,31,'#050a13ed',7);texto(fx,c.text,480,505,18,blanco,500)}
}
const timeline=gsap.timeline({paused:true});timeline.to(reloj,{s:60,duration:60,ease:'none',onUpdate:()=>render(reloj.s)},0);
window.__timelines={'hilo-dorado':timeline};
window.mediaReady=Promise.all([...precarga,document.fonts.load('800 72px Inter'),document.fonts.load('500 18px Inter')]).then(()=>{listo=true;render(reloj.s)});
